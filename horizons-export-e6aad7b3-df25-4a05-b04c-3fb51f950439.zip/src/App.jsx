
import React from "react";
import { motion } from "framer-motion";
import Header from "@/components/Header";
import TextToSpeechForm from "@/components/TextToSpeechForm";
import HowToUse from "@/components/HowToUse";
import UseCases from "@/components/UseCases";
import Footer from "@/components/Footer";
import { Toaster } from "@/components/ui/toaster";

const App = () => {
  return (
    <div className="min-h-screen gradient-bg noise-bg grid-pattern">
      <div className="container mx-auto px-4">
        <Header />
        
        <motion.main 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="py-8"
        >
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="bg-black/20 backdrop-blur-sm border border-primary/20 rounded-xl p-6 md:p-8 mb-16 shadow-lg glow"
          >
            <TextToSpeechForm />
          </motion.div>
          
          <HowToUse />
          <UseCases />
        </motion.main>
        
        <Footer />
      </div>
      <Toaster />
    </div>
  );
};

export default App;
