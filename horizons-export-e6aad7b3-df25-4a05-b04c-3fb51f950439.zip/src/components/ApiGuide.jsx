
import React from "react";
import { motion } from "framer-motion";
import { Code, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

const ApiGuide = () => {
  const codeExample = `// Example code for using Hugging Face API
const response = await fetch(
  "https://api-inference.huggingface.co/models/facebook/mms-tts",
  {
    headers: { Authorization: "Bearer YOUR_API_KEY" },
    method: "POST",
    body: JSON.stringify({
      inputs: "Your text to convert to speech",
      options: {
        wait_for_model: true,
        language: "en",
        speaker_id: "female"
      }
    }),
  }
);
const result = await response.blob();
const audioUrl = URL.createObjectURL(result);
// Now you can play this audio or download it`;

  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="py-12 bg-black/30 rounded-xl border border-primary/20 my-16"
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold orbitron mb-4">Integrate with Hugging Face API</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Follow these steps to use the Hugging Face API for production-ready text-to-speech conversion
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-2"
            >
              <h3 className="text-xl font-semibold flex items-center">
                <span className="inline-block w-6 h-6 rounded-full bg-primary text-white text-center mr-2">1</span>
                Create a Hugging Face Account
              </h3>
              <p className="text-muted-foreground pl-8">
                Sign up for a free account at Hugging Face to get your API key.
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="space-y-2"
            >
              <h3 className="text-xl font-semibold flex items-center">
                <span className="inline-block w-6 h-6 rounded-full bg-primary text-white text-center mr-2">2</span>
                Choose a Text-to-Speech Model
              </h3>
              <p className="text-muted-foreground pl-8">
                Select from various TTS models like facebook/mms-tts or espnet/kan-bayashi_ljspeech_vits.
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="space-y-2"
            >
              <h3 className="text-xl font-semibold flex items-center">
                <span className="inline-block w-6 h-6 rounded-full bg-primary text-white text-center mr-2">3</span>
                Make API Requests
              </h3>
              <p className="text-muted-foreground pl-8">
                Use the fetch API to make requests to the Hugging Face Inference API.
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="space-y-2"
            >
              <h3 className="text-xl font-semibold flex items-center">
                <span className="inline-block w-6 h-6 rounded-full bg-primary text-white text-center mr-2">4</span>
                Handle the Audio Response
              </h3>
              <p className="text-muted-foreground pl-8">
                Process the binary audio data returned by the API and convert it to a playable format.
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="pt-4"
            >
              <Button 
                className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                onClick={() => window.open("https://huggingface.co/docs/api-inference/detailed_parameters#text-to-speech-task", "_blank")}
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Hugging Face API Documentation
              </Button>
            </motion.div>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-black/50 rounded-lg p-4 border border-primary/30"
          >
            <div className="flex items-center justify-between mb-2 text-sm text-muted-foreground">
              <div className="flex items-center">
                <Code className="h-4 w-4 mr-2" />
                <span>JavaScript Example</span>
              </div>
            </div>
            <pre className="text-sm overflow-x-auto p-4 rounded bg-black/30 text-gray-300">
              <code>{codeExample}</code>
            </pre>
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
};

export default ApiGuide;
