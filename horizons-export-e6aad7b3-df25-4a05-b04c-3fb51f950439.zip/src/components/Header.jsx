
import React from "react";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

const Header = () => {
  return (
    <header className="py-6 md:py-10">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center text-center"
        >
          <div className="flex items-center mb-2">
            <motion.div
              initial={{ rotate: 0 }}
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            >
              <Sparkles className="h-8 w-8 text-purple-500 mr-2" />
            </motion.div>
            <h1 className="text-3xl md:text-4xl font-bold orbitron gradient-text">
              RUDE_X PROJECT
            </h1>
          </div>
          
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="text-lg md:text-xl text-muted-foreground max-w-2xl"
          >
            Transform your text into natural-sounding speech with our advanced AI voice generator
          </motion.p>
        </motion.div>
      </div>
    </header>
  );
};

export default Header;
