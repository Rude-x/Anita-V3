
import React from "react";
import { motion } from "framer-motion";
import { Github, Twitter, Heart } from "lucide-react";

const Footer = () => {
  return (
    <motion.footer 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.5 }}
      className="mt-16 pb-8 text-center"
    >
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center border-t border-primary/10 pt-8">
          <div className="mb-4 md:mb-0">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} RUDE_X PROJECT. All rights reserved.
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <motion.a 
              href="#" 
              whileHover={{ scale: 1.1 }}
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Github size={18} />
            </motion.a>
            <motion.a 
              href="#" 
              whileHover={{ scale: 1.1 }}
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Twitter size={18} />
            </motion.a>
            <motion.div 
              className="flex items-center text-sm text-muted-foreground"
            >
              Made with <Heart size={14} className="mx-1 text-red-500" /> by RUDE_X
            </motion.div>
          </div>
        </div>
      </div>
    </motion.footer>
  );
};

export default Footer;
