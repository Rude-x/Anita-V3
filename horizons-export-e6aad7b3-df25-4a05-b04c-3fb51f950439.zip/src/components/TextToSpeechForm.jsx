
import React, { useState, useRef } from "react";
import { motion } from "framer-motion";
import { Play, Pause, Download, Volume2, Mic, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import AudioWave from "@/components/AudioWave";

const TextToSpeechForm = () => {
  const [text, setText] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState(null);
  const [selectedVoice, setSelectedVoice] = useState("en_female");
  const [speed, setSpeed] = useState([1.0]);
  const [savedAudios, setSavedAudios] = useState(() => {
    const saved = localStorage.getItem("rudex_saved_audios");
    return saved ? JSON.parse(saved) : [];
  });
  
  const audioRef = useRef(null);
  const { toast } = useToast();

  const voices = [
    { id: "en_female", name: "English (Female)" },
    { id: "en_male", name: "English (Male)" },
    { id: "fr_female", name: "French (Female)" },
    { id: "de_male", name: "German (Male)" },
    { id: "es_female", name: "Spanish (Female)" },
    { id: "jp_female", name: "Japanese (Female)" },
  ];

  const handleTextChange = (e) => {
    setText(e.target.value);
  };

  const handleVoiceChange = (value) => {
    setSelectedVoice(value);
  };

  const handleSpeedChange = (value) => {
    setSpeed(value);
  };

  const generateSpeech = async () => {
    if (!text.trim()) {
      toast({
        title: "Error",
        description: "Please enter some text to convert to speech",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    
    try {
      // In a real implementation, this would call the Hugging Face API
      // For this demo, we're simulating the API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simulate a successful response with a mock audio URL
      // In a real implementation, this would be the URL returned by the API
      const mockAudioBlob = await simulateTextToSpeech(text);
      const mockAudioUrl = URL.createObjectURL(mockAudioBlob);
      
      setAudioUrl(mockAudioUrl);
      
      if (audioRef.current) {
        audioRef.current.src = mockAudioUrl;
        audioRef.current.playbackRate = speed[0];
      }
      
      toast({
        title: "Success",
        description: "Speech generated successfully!",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate speech. Please try again.",
        variant: "destructive",
      });
      console.error("Error generating speech:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  // This function simulates text-to-speech conversion
  // In a real implementation, this would be replaced with an actual API call
  const simulateTextToSpeech = async (text) => {
    // Create an oscillator to generate a simple tone
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.type = 'sine';
    oscillator.frequency.value = 440; // A4 note
    gainNode.gain.value = 0.1;
    
    // Record the oscillator output
    const duration = Math.min(5, Math.max(1, text.length / 20)); // Duration based on text length
    const sampleRate = 44100;
    const frameCount = sampleRate * duration;
    
    const audioBuffer = audioContext.createBuffer(1, frameCount, sampleRate);
    const channelData = audioBuffer.getChannelData(0);
    
    // Fill the buffer with a simple waveform
    for (let i = 0; i < frameCount; i++) {
      // Create a more complex waveform to simulate speech
      const t = i / sampleRate;
      const f = 150 + 50 * Math.sin(2 * Math.PI * 0.5 * t); // Varying frequency
      channelData[i] = 0.2 * Math.sin(2 * Math.PI * f * t) * Math.exp(-t / duration);
    }
    
    // Convert the buffer to a WAV file
    const audioBlob = await audioBufferToWav(audioBuffer);
    return audioBlob;
  };

  // Helper function to convert AudioBuffer to WAV format
  const audioBufferToWav = async (buffer) => {
    const numOfChannels = buffer.numberOfChannels;
    const length = buffer.length * numOfChannels * 2;
    const sampleRate = buffer.sampleRate;
    
    const wav = new ArrayBuffer(44 + length);
    const view = new DataView(wav);
    
    // Write WAV header
    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + length, true);
    writeString(view, 8, 'WAVE');
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, numOfChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * numOfChannels * 2, true);
    view.setUint16(32, numOfChannels * 2, true);
    view.setUint16(34, 16, true);
    writeString(view, 36, 'data');
    view.setUint32(40, length, true);
    
    // Write audio data
    const channelData = [];
    for (let i = 0; i < numOfChannels; i++) {
      channelData.push(buffer.getChannelData(i));
    }
    
    let offset = 44;
    for (let i = 0; i < buffer.length; i++) {
      for (let channel = 0; channel < numOfChannels; channel++) {
        const sample = Math.max(-1, Math.min(1, channelData[channel][i]));
        view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7FFF, true);
        offset += 2;
      }
    }
    
    return new Blob([wav], { type: 'audio/wav' });
  };

  const writeString = (view, offset, string) => {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  };

  const playAudio = () => {
    if (audioRef.current && audioUrl) {
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  const pauseAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };

  const downloadAudio = () => {
    if (audioUrl) {
      const a = document.createElement("a");
      a.href = audioUrl;
      a.download = `rudex_speech_${Date.now()}.wav`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      toast({
        title: "Download started",
        description: "Your audio file is being downloaded",
      });
    }
  };

  const saveAudio = () => {
    if (audioUrl && text) {
      const newAudio = {
        id: Date.now(),
        text: text.substring(0, 50) + (text.length > 50 ? "..." : ""),
        url: audioUrl,
        voice: selectedVoice,
        speed: speed[0],
        date: new Date().toISOString(),
      };
      
      const updatedSavedAudios = [...savedAudios, newAudio];
      setSavedAudios(updatedSavedAudios);
      localStorage.setItem("rudex_saved_audios", JSON.stringify(updatedSavedAudios));
      
      toast({
        title: "Saved",
        description: "Audio saved to your library",
      });
    }
  };

  const deleteAudio = (id) => {
    const updatedSavedAudios = savedAudios.filter(audio => audio.id !== id);
    setSavedAudios(updatedSavedAudios);
    localStorage.setItem("rudex_saved_audios", JSON.stringify(updatedSavedAudios));
    
    toast({
      title: "Deleted",
      description: "Audio removed from your library",
    });
  };

  const playSavedAudio = (audioUrl, speed) => {
    if (audioRef.current) {
      audioRef.current.src = audioUrl;
      audioRef.current.playbackRate = speed;
      audioRef.current.play();
      setIsPlaying(true);
      setAudioUrl(audioUrl);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <audio 
        ref={audioRef} 
        onEnded={() => setIsPlaying(false)}
        onPause={() => setIsPlaying(false)}
      />
      
      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="text" className="text-lg font-medium">Enter your text</Label>
          <Textarea
            id="text"
            placeholder="Type or paste text here to convert to speech..."
            className="min-h-[150px] text-base border-primary/20 focus:border-primary"
            value={text}
            onChange={handleTextChange}
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="voice" className="text-base font-medium">Voice</Label>
            <Select value={selectedVoice} onValueChange={handleVoiceChange}>
              <SelectTrigger id="voice" className="w-full">
                <SelectValue placeholder="Select a voice" />
              </SelectTrigger>
              <SelectContent>
                {voices.map((voice) => (
                  <SelectItem key={voice.id} value={voice.id}>
                    {voice.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="speed" className="text-base font-medium">Speed: {speed[0]}x</Label>
            <Slider
              id="speed"
              min={0.5}
              max={2}
              step={0.1}
              value={speed}
              onValueChange={handleSpeedChange}
              className="py-2"
            />
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button 
              onClick={generateSpeech} 
              disabled={isGenerating || !text.trim()} 
              className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
            >
              <Mic className="mr-2 h-4 w-4" />
              {isGenerating ? "Generating..." : "Generate Speech"}
            </Button>
          </motion.div>
          
          {audioUrl && (
            <>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  onClick={isPlaying ? pauseAudio : playAudio} 
                  variant="outline" 
                  className="border-purple-500 text-purple-500 hover:bg-purple-500/10"
                >
                  {isPlaying ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
                  {isPlaying ? "Pause" : "Play"}
                </Button>
              </motion.div>
              
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  onClick={downloadAudio} 
                  variant="outline"
                  className="border-blue-500 text-blue-500 hover:bg-blue-500/10"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
              </motion.div>
              
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  onClick={saveAudio} 
                  variant="outline"
                  className="border-green-500 text-green-500 hover:bg-green-500/10"
                >
                  <Save className="mr-2 h-4 w-4" />
                  Save
                </Button>
              </motion.div>
            </>
          )}
        </div>
        
        {audioUrl && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 p-4 rounded-lg bg-primary/5 border border-primary/20"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Volume2 className="h-5 w-5 text-primary mr-2" />
                <span className="font-medium">Audio Preview</span>
              </div>
              <AudioWave isPlaying={isPlaying} />
            </div>
          </motion.div>
        )}
        
        {savedAudios.length > 0 && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-8"
          >
            <h3 className="text-xl font-bold mb-4 orbitron gradient-text">Your Saved Audio Library</h3>
            <div className="space-y-3">
              {savedAudios.map((audio) => (
                <motion.div 
                  key={audio.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-3 rounded-lg bg-secondary/20 border border-secondary/30 flex justify-between items-center"
                >
                  <div className="flex-1 mr-4">
                    <p className="font-medium text-sm">{audio.text}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(audio.date).toLocaleDateString()} • {voices.find(v => v.id === audio.voice)?.name} • {audio.speed}x
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => playSavedAudio(audio.url, audio.speed)}
                      className="h-8 w-8 p-0"
                    >
                      <Play className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => deleteAudio(audio.id)}
                      className="h-8 w-8 p-0 text-destructive hover:text-destructive/90 hover:bg-destructive/10"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default TextToSpeechForm;
