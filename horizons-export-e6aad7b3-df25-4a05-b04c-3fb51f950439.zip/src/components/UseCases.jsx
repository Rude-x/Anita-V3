
import React from "react";
import { motion } from "framer-motion";
import { Video, BookOpen, Presentation, Headphones, Megaphone, Globe } from "lucide-react";

const UseCases = () => {
  const useCases = [
    {
      icon: <Video className="h-8 w-8 text-purple-500" />,
      title: "Video Content",
      description: "Create voiceovers for videos, tutorials, and explainer content."
    },
    {
      icon: <BookOpen className="h-8 w-8 text-indigo-500" />,
      title: "Audiobooks",
      description: "Convert written stories and articles into audio format."
    },
    {
      icon: <Presentation className="h-8 w-8 text-blue-500" />,
      title: "Presentations",
      description: "Add professional narration to your slides and presentations."
    },
    {
      icon: <Headphones className="h-8 w-8 text-green-500" />,
      title: "Podcasts",
      description: "Generate intro/outro segments or full episodes for podcasts."
    },
    {
      icon: <Megaphone className="h-8 w-8 text-orange-500" />,
      title: "Announcements",
      description: "Create clear audio announcements for events or public spaces."
    },
    {
      icon: <Globe className="h-8 w-8 text-pink-500" />,
      title: "Language Learning",
      description: "Hear proper pronunciation of phrases in different languages."
    }
  ];

  return (
    <section className="py-12 bg-gradient-to-b from-background to-background/50">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h2 className="text-2xl md:text-3xl font-bold orbitron mb-4">What You Can Create</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore the many ways you can use RUDE_X text-to-speech technology
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {useCases.map((useCase, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-secondary/5 backdrop-blur-sm border border-primary/10 rounded-xl p-6 hover:border-primary/30 transition-all duration-300"
            >
              <div className="mb-4">
                {useCase.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{useCase.title}</h3>
              <p className="text-muted-foreground">{useCase.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default UseCases;
