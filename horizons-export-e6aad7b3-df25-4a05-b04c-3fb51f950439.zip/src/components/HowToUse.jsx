
import React from "react";
import { motion } from "framer-motion";
import { Keyboard, Volume, Download, Bookmark } from "lucide-react";

const HowToUse = () => {
  const steps = [
    {
      icon: <Keyboard className="h-10 w-10 text-purple-500" />,
      title: "Enter Your Text",
      description: "Type or paste the text you want to convert to speech in the text area."
    },
    {
      icon: <Volume className="h-10 w-10 text-indigo-500" />,
      title: "Generate & Listen",
      description: "Choose your preferred voice and speed, then click 'Generate Speech' to create audio."
    },
    {
      icon: <Download className="h-10 w-10 text-blue-500" />,
      title: "Download & Share",
      description: "Download your generated audio file to use in videos, presentations, or share with others."
    },
    {
      icon: <Bookmark className="h-10 w-10 text-green-500" />,
      title: "Save for Later",
      description: "Save your generated audio to your library for quick access later."
    }
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h2 className="text-2xl md:text-3xl font-bold orbitron mb-4">How to Use RUDE_X</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Follow these simple steps to convert your text to natural-sounding speech in seconds
          </p>
        </motion.div>
        
        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {steps.map((step, index) => (
            <motion.div
              key={index}
              variants={item}
              className="bg-secondary/5 backdrop-blur-sm border border-primary/10 rounded-xl p-6 flex flex-col items-center text-center hover:border-primary/30 transition-all duration-300"
            >
              <div className="mb-4 p-3 rounded-full bg-background/50 border border-primary/20">
                {step.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
              <p className="text-muted-foreground">{step.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default HowToUse;
