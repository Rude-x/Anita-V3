
import React from "react";
import { motion } from "framer-motion";

const AudioWave = ({ isPlaying }) => {
  return (
    <div className={`audio-wave ${isPlaying ? "" : "paused"}`}>
      <motion.div 
        className="bar"
        initial={{ height: 5 }}
        animate={{ height: isPlaying ? [5, 20, 5] : 5 }}
        transition={{ repeat: Infinity, duration: 1, ease: "easeInOut" }}
      />
      <motion.div 
        className="bar"
        initial={{ height: 5 }}
        animate={{ height: isPlaying ? [5, 15, 5] : 5 }}
        transition={{ repeat: Infinity, duration: 0.8, ease: "easeInOut", delay: 0.1 }}
      />
      <motion.div 
        className="bar"
        initial={{ height: 5 }}
        animate={{ height: isPlaying ? [5, 25, 5] : 5 }}
        transition={{ repeat: Infinity, duration: 0.7, ease: "easeInOut", delay: 0.2 }}
      />
      <motion.div 
        className="bar"
        initial={{ height: 5 }}
        animate={{ height: isPlaying ? [5, 18, 5] : 5 }}
        transition={{ repeat: Infinity, duration: 0.9, ease: "easeInOut", delay: 0.3 }}
      />
      <motion.div 
        className="bar"
        initial={{ height: 5 }}
        animate={{ height: isPlaying ? [5, 30, 5] : 5 }}
        transition={{ repeat: Infinity, duration: 0.8, ease: "easeInOut", delay: 0.4 }}
      />
      <motion.div 
        className="bar"
        initial={{ height: 5 }}
        animate={{ height: isPlaying ? [5, 22, 5] : 5 }}
        transition={{ repeat: Infinity, duration: 1.1, ease: "easeInOut", delay: 0.5 }}
      />
      <motion.div 
        className="bar"
        initial={{ height: 5 }}
        animate={{ height: isPlaying ? [5, 15, 5] : 5 }}
        transition={{ repeat: Infinity, duration: 0.7, ease: "easeInOut", delay: 0.6 }}
      />
      <motion.div 
        className="bar"
        initial={{ height: 5 }}
        animate={{ height: isPlaying ? [5, 20, 5] : 5 }}
        transition={{ repeat: Infinity, duration: 0.9, ease: "easeInOut", delay: 0.7 }}
      />
    </div>
  );
};

export default AudioWave;
